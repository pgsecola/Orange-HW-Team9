library(graphics)
library(ks)


drill_cost<-read.csv('/Users/peixingli/Desktop/Simulation/Drilling cost.csv',header=FALSE, stringsAsFactors = FALSE)

x1<-drill_cost$V5[!is.na(drill_cost$V5)]
x2<-drill_cost$V6[!is.na(drill_cost$V6)]
x3<-drill_cost$V7[!is.na(drill_cost$V7)]

#output desnity bw from historical data 
Density.x1 <- density(x1, bw="SJ-ste")
Density.x2 <- density(x2, bw="SJ-ste")
Density.x3 <- density(x3, bw="SJ-ste")
Density.x1$bw
cost1_2006=drill_cost$V2[47]
cost2_2006=drill_cost$V3[47]
cost3_2006=drill_cost$V4[47]

ntimes = 100000
cost2019_mean = rep(NA, ntimes)


for(j in 1:ntimes){
  Est.x1 <- rkde(fhat=kde(x1, h=Density.x1$bw), n=13)
  cost1<-cost1_2006*(prod(1+Est.x1))
  Est.x2 <- rkde(fhat=kde(x2, h=Density.x2$bw), n=13)
  cost2<-cost2_2006*(prod(1+Est.x2))
  Est.x3 <- rkde(fhat=kde(x3, h=Density.x2$bw), n=13)
  cost3<-cost3_2006*(prod(1+Est.x3))
  cost2019_mean[j]=(mean(cost1+cost2+cost3)/3)
  
}
summary(cost2019_mean)
hist(cost2019_mean, breaks=100, main='2019 cost estimationg', xlab='Average Cost')

hist(Est.x1, breaks=50, main='Estimated One Year Value Distribution', xlab='Final Value')
hist(x1, breaks=10, main='historical Distribution', xlab='percentage change')
#check cost simulated visualzie histogram
